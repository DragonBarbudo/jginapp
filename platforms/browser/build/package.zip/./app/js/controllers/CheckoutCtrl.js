
moduleapp.controller('CheckoutCtrl', function ($scope, ShoppingCartSvc, SettingSvc, StoreLocalSvc, ProductsSvc, PaypalSvc, geolocation, uiGmapGoogleMapApi, $rootScope, cfpLoadingBar, UtilsSvc, OrdersSvc) {
    $scope.total = [];

    $scope.cartItems = ShoppingCartSvc.getCart();
    $scope.url = SettingSvc.getPhotoUrl();

    $scope.cartCount;

    $scope.address="";
    $scope.geocoder = new google.maps.Geocoder();


    $scope.order = {
  		code: UtilsSvc.createRandomCode(),
  		date_time: UtilsSvc.formatDate(new Date(), "dddd h:mmtt d MMM yyyy"),
  		customer_firstname: "",
  		customer_lastname: "",
  		customer_email_address: "",
  		customer_country : "",
  		customer_city: "",
  		customer_address: "",
  		customer_zipcode : "",
  		customer_phone_number: "",
  		customer_note : "",
  		total_amount : 0,
  		customer_shipping_class: "",
  		customer_shipping_price: "",
  		payment_type: ""
  	}


    console.log($scope.order.date_time);

    getTotalAmount();

    $scope.totalAmount = function(){
  		$scope.order.total_amount = 0;
  		for(var i=0;i<$scope.cartItems.length;i++){
  			$scope.order.total_amount += $scope.cartItems[i].subTotal;
  		}
  		return $scope.order.total_amount;
  	}

    function getTotalAmount(){
      $scope.order.total_amount = 0;
  		for(var i=0;i<$scope.cartItems.length;i++){
        $scope.cartItems[i].subTotal= $scope.cartItems[i].quantity * $scope.cartItems[i].new_price;
  			$scope.order.total_amount += $scope.cartItems[i].subTotal;
  		}
    }

    $scope.checkoutPosition;



    geolocation.getLocation().then(function(data){
      var geocoder = new google.maps.Geocoder();
      uiGmapGoogleMapApi.then(function(maps) {
      setTimeout(function(){ $('.Cart .gm-style').append('<div class="centerPin"><img src="app/img/icon_marker.png"></div>'); }, 1000);
        $scope.coords = { lat:data.coords.latitude, lng: data.coords.longitude };
          $scope.map = {
              center: { latitude: $scope.coords.lat, longitude: $scope.coords.lng },
            zoom: 11,
            options: {
              mapTypeId: google.maps.MapTypeId.ROADMAP,
              mapTypeControl: false,
              streetViewControl: false
            },
            events:{
              dragend: function(e){

                var point = e.center;
                $scope.isInZone = area.containsLatLng(point);
                if($scope.isInZone){ trackLocation($scope.map.center.latitude, $scope.map.center.longitude); }
              }
            }
          }
          $scope.polygons = zonaJagergin;

          // ¿INSIDE JAGERGIN ZONE?
          var nupaths = { path:[ ] };
          for(var i=0;i<zonaJagergin.todo.path.length; i++){  nupaths.path.push( {lat:zonaJagergin.todo.path[i].latitude, lng:zonaJagergin.todo.path[i].longitude } );  }
          var area = new google.maps.Polygon( {paths: nupaths.path });
          var point = new google.maps.LatLng($scope.coords.lat, $scope.coords.lng);
          $scope.isInZone = area.containsLatLng(point);
          if($scope.isInZone){ trackLocation($scope.coords.lat, $scope.coords.lng); }
      }); //ends uiGmapGoogleMapApi

    }); //ends geolocation


    $scope.order.address = {};
    $scope.order.address.inmediato = true;
    /*
    $scope.hrentrega = function(){
      $scope.order.address.inmediato = inmediato.isChecked();
      console.log($scope.order.address.inmediato);
    }
*/
    function trackLocation(lat, lng){
      cfpLoadingBar.start();
      $scope.geocoder.geocode({ 'latLng': new google.maps.LatLng(lat, lng) }, function (results, status) {
          if (status == google.maps.GeocoderStatus.OK) {
              if (results[1]) {
                  $scope.order.address.general = results[0].formatted_address;
                  cfpLoadingBar.complete();
              } else {
                  $scope.order.address.general =  'No encontramos tu dirección';
                  cfpLoadingBar.complete()
              }
          } else {
              $scope.order.address.general =  'Error: ' + status;
          }
      });
    }






        function createOrder(){
          console.log("Creando orden: " + JSON.stringify($scope.order, null, 4));
          ShoppingCartSvc.clear();
          OrdersSvc.create($scope.order).then(function(result){
            for(var i=0; i<$scope.cartItems.length;i++){
              var orderItem = {
                order_id: result.data,
                product_price: $scope.cartItems[i].new_price,
                product_quantity: parseInt($scope.cartItems[i].quantity),
                product_name: $scope.cartItems[i].name,
                product_category: $scope.cartItems[i].category_name,
                product_spec: JSON.stringify([{
                  title: $scope.cartItems[i].spec_title,
                  value: $scope.cartItems[i].spec_value
                }])
              }
              OrderItemSvc.create(orderItem).then(function(result){
              console.log('item id : ',result.data);
              });
            }
            menu.setMainPage('app/view/cuenta.html');
          });
        }



        // PAY
        $scope.pay = function(){
          console.log('Pagar');
          PayPalMobile.renderSinglePaymentUI(PaypalSvc.createPayment($scope.order.total_amount), onSuccesfulPayment, onUserCanceled);
        }


        function onSuccesfulPayment(payment) {
         	console.log("payment success: " + JSON.stringify(payment, null, 4));
         	createOrder();
       	}
       	function onAuthorizationCallback(authorization) {
         	console.log("authorization: " + JSON.stringify(authorization, null, 4));
       	}
       	function onUserCanceled(authorization) {
         	console.log("canceled: " + JSON.stringify(authorization, null, 4));
       	}


        if(typeof PayPalMobile != 'undefined'){ PaypalSvc.initPaymentUI(); }





});
